public class UsarRectangulo {               
         public static void main(String [ ] args){
			 
			     /*
				 //Primer cuadrante
                 Punto A1 = new Punto("A1",3,2);
                 Punto B1 = new Punto("B1",7,4);
				 Rectangulo R1 = new Rectangulo("R1",A1,B1);//Primer rectangulo
				 
				 Rectangulo R2 = new Rectangulo("R2");//Segundo rectangulo
				 Punto A2 = new Punto("A2",5,3);
				 Punto B2 = new Punto("B2",10,7);
				 R2.moverRect(A2,B2);//Movemos el segundo rectangulo
		
				 Rectangulo R3 = R1.union(R2);
				 Rectangulo R4 = R1.interseccion(R2);
				 
				 
				 System.out.println("El rectangulo " + R1 + ",de area:" + R1.area());
				 System.out.println("Unido con el rectangulo " + R2 + ",de area:" + R2.area());
				 System.out.println("Es el rectangulo " + R3 + ",de area: " + R3.area());
				 System.out.println("Su interseccion es el rectangulo " + R4 + " ,de cuadrante " + R4.cuadRect());
				 
				 //Movemos el rectangulo R2
				 Punto P1 = new Punto(0,0);
				 Punto P2 = new Punto(7,5);
				 R2.moverRect(P1,P2);
				 if(R2.comparar(R3)==0){
					 System.out.println("El rectangulo "+R2+" es igual al rectangulo "+R3);
				 }
				 if(R2.comparar(R3)>0){
					 System.out.println("El rectangulo "+R2+" es mayor al rectangulo "+R3);
				 }
				 if(R2.comparar(R3)<0){
					 System.out.println("El rectangulo "+R2+" es menor al rectangulo "+R3);
				 }
				 */
				
				/*
				 //Segundo cuadrante
				 Punto A1 = new Punto("A1",-7,4);
                 Punto B1 = new Punto("B1",-4,6);
				 Rectangulo R1 = new Rectangulo("R1",A1,B1);//Primer rectangulo
				 
				 Rectangulo R2 = new Rectangulo("R2");//Segundo rectangulo
				 Punto A2 = new Punto("A2",-9,2);
				 Punto B2 = new Punto("B2",-3,8);
				 R2.moverRect(A2,B2);//Movemos el segundo rectangulo
		
				 Rectangulo R3 = R1.union(R2);
				 Rectangulo R4 = R1.interseccion(R2);
				 
				 
				 System.out.println("El rectangulo " + R1 + ",de area:" + R1.area());
				 System.out.println("Unido con el rectangulo " + R2 + ",de area:" + R2.area());
				 System.out.println("Es el rectangulo " + R3 + ",de area: " + R3.area());
				 System.out.println("Su interseccion es el rectangulo " + R4 + " ,de cuadrante " + R4.cuadRect());
				 
				 //Movemos el rectangulo R2
				 Punto P1 = new Punto(0,0);
				 Punto P2 = new Punto(-7,5);
				 R2.moverRect(P1,P2);
				 if(R2.comparar(R3)==0){
					 System.out.println("El rectangulo "+R2+" es igual al rectangulo "+R3);
				 }
				 if(R2.comparar(R3)>0){
					 System.out.println("El rectangulo "+R2+" es mayor al rectangulo "+R3);
				 }
				 if(R2.comparar(R3)<0){
					 System.out.println("El rectangulo "+R2+" es menor al rectangulo "+R3);
				 }
				 */
				 /*
				 //Tercer cuadrante
				 Punto A1 = new Punto("A1",-6,-7);
                 Punto B1 = new Punto("B1",-4,-3);
				 Rectangulo R1 = new Rectangulo("R1",A1,B1);//Primer rectangulo
				 
				 Rectangulo R2 = new Rectangulo("R2");//Segundo rectangulo
				 Punto A2 = new Punto("A2",-7,-5);
				 Punto B2 = new Punto("B2",-3,-2);
				 R2.moverRect(A2,B2);//Movemos el segundo rectangulo
		
				 Rectangulo R3 = R1.union(R2);
				 Rectangulo R4 = R1.interseccion(R2);
				 
				 
				 System.out.println("El rectangulo " + R1 + ",de area:" + R1.area());
				 System.out.println("Unido con el rectangulo " + R2 + ",de area:" + R2.area());
				 System.out.println("Es el rectangulo " + R3 + ",de area: " + R3.area());
				 System.out.println("Su interseccion es el rectangulo " + R4 + " ,de cuadrante " + R4.cuadRect());
				 
				 //Movemos el rectangulo R2
				 Punto P1 = new Punto(0,0);
				 Punto P2 = new Punto(-7,-5);
				 R2.moverRect(P1,P2);
				 if(R2.comparar(R3)==0){
					 System.out.println("El rectangulo "+R2+" es igual al rectangulo "+R3);
				 }
				 if(R2.comparar(R3)>0){
					 System.out.println("El rectangulo "+R2+" es mayor al rectangulo "+R3);
				 }
				 if(R2.comparar(R3)<0){
					 System.out.println("El rectangulo "+R2+" es menor al rectangulo "+R3);
				 }
				 */
				 
				 //Cuarto cuadrante
				 Punto A1 = new Punto("A1",2,-6);
                 Punto B1 = new Punto("B1",5,-3);
				 Rectangulo R1 = new Rectangulo("R1",A1,B1);//Primer rectangulo
				 
				 Rectangulo R2 = new Rectangulo("R2");//Segundo rectangulo
				 Punto A2 = new Punto("A2",4,-8);
				 Punto B2 = new Punto("B2",8,-4);
				 R2.moverRect(A2,B2);//Movemos el segundo rectangulo
		
				 Rectangulo R3 = R1.union(R2);
				 Rectangulo R4 = R1.interseccion(R2);
				 
				 
				 System.out.println("El rectangulo " + R1 + ",de area:" + R1.area());
				 System.out.println("Unido con el rectangulo " + R2 + ",de area:" + R2.area());
				 System.out.println("Es el rectangulo " + R3 + ",de area: " + R3.area());
				 System.out.println("Su interseccion es el rectangulo " + R4 + " ,de cuadrante " + R4.cuadRect());
				 
				 //Movemos el rectangulo R2
				 Punto P1 = new Punto(0,0);
				 Punto P2 = new Punto(7,-5);
				 R2.moverRect(P1,P2);
				 if(R2.comparar(R3)==0){
					 System.out.println("El rectangulo "+R2+" es igual al rectangulo "+R3);
				 }
				 if(R2.comparar(R3)>0){
					 System.out.println("El rectangulo "+R2+" es mayor al rectangulo "+R3);
				 }
				 if(R2.comparar(R3)<0){
					 System.out.println("El rectangulo "+R2+" es menor al rectangulo "+R3);
				 }
         } 
}