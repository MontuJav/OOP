public class Punto {
        // Atributo con acceso privado
        private int x;
        private int y;
        private String nombre;
		
        // Constructor: inicializa objetos
        public Punto(){
           x=y=0;
		   nombre="O";
        }
		
		public Punto(String nombre, int x, int y){
		 this.nombre=nombre;
		 this.x=x;
		 this.y=y;
		}
		
		public Punto(int x, int y){
		 nombre="Q";
		 this.x=x;
		 this.y=y;
		}
		
		public Punto(Punto Q){
			this.x=Q.x;
			this.y=Q.y;
		}
		
        //Métodos
		//getter's
        public int getX(){
              return x;
        }
		public int getY(){
		 return y;
		}
		public String nombre(){
		 return nombre;
		}
		//setter´s
		public void setX(int n){x=n;}
		public void setY(int n){y=n;}
		public void setNombre(String name){nombre=name;}
		public void mover(int x, int y){
			this.x=x;
			this.y=y;
		}
		public void equals(Punto P){
			this.x=P.x;
			this.y=P.y;
		}
		//toString
		public String toString(){
			String mensaje=nombre+"("+x+","+y+")";
			return mensaje;
		}
		//distancia
		public double distancia(Punto o){
			return Math.sqrt(Math.pow(o.x-this.x,2)+Math.pow(o.y-this.y,2));
		}
		
		public double distancia(){
			return Math.sqrt(Math.pow(x,2)+Math.pow(y,2));
		}
		//cuadrante: 1,2,3 o 4, devuelve 1 si es el origen
		public int cuadrante(){
			if(x>=0){
				if(y>=0){return 1;}
				else{return 4;}
			}
			else{
				if(y>=0){return 2;}
				else{return 3;}
			}
		}
		//true si el que invoca esta abajo
		public boolean Abajo(Punto B){
			return this.y<B.y;
		}
		//true si el que invoca esta a la izquierda
		public boolean Izquierda(Punto B){
			return this.x<B.x;
		}
    
}
    
